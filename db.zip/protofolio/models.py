from django.db import models
from PIL import Image

# Create your models here.
class Contact(models.Model):
    sno = models.AutoField(primary_key=True)
    fname = models.CharField(max_length=255)
    lname = models.CharField(max_length=255)
    email = models.CharField(max_length=100)
    mobile = models.CharField(max_length=13)    
    subject = models.CharField(max_length=100)    
    message = models.TextField() 
    timestamp = models.DateTimeField(auto_now_add=True, blank=True)   

    def __str__(self):
        return 'Message from '+self.fname+' _ '+self.email 


class User(models.Model):
    sno = models.AutoField(primary_key=True)
    title = models.CharField(max_length=1)
    title1 = models.CharField(max_length=10)
    title2 = models.CharField(max_length=1)
    title3 = models.CharField(max_length=10)
    greatings = models.CharField(max_length=255)
    name = models.CharField(max_length=50)
    workname = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    image = models.ImageField( upload_to='media/')
    circle_text = models.CharField(max_length=255,)
    pdf = models.FileField(upload_to='media/')
    insta = models.URLField()
    facebook = models.URLField()
    whatsapp = models.URLField()
    telegram = models.URLField()
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class About(models.Model):
    about_image = models.ImageField(upload_to='media/')
    work_experience = models.CharField(max_length=50)
    intro = models.CharField(max_length=255)
    main_skill_p1 = models.CharField(max_length=255)
    main_skill_p2 = models.CharField(max_length=255)
    main_skill_p3 = models.CharField(max_length=255)
    main_skill_span1 = models.CharField(max_length=255)
    main_skill_span2 = models.CharField(max_length=255)
    main_skill_span3 = models.CharField(max_length=255)
    awards_p1 = models.CharField(max_length=255)
    awards_p2 = models.CharField(max_length=255)
    awards_p3 = models.CharField(max_length=255)
    awards_span1 = models.CharField(max_length=255)
    awards_span2 = models.CharField(max_length=255)
    awards_span3 = models.CharField(max_length=255)
    education_p1 = models.CharField(max_length=255)
    education_p2 = models.CharField(max_length=255)
    education_p3 = models.CharField(max_length=255)
    education_span1 = models.CharField(max_length=255)
    education_span2 = models.CharField(max_length=255)
    education_span3 = models.CharField(max_length=255)
    pdf = models.FileField(upload_to='media/')
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.intro


# my_services
class Services(models.Model):
    icon = models.CharField(max_length=255)
    service_name = models.CharField(max_length=255)
    service_intro = models.CharField(max_length=255)

    def __str__(self):
        return self.service_name

# my_services_2
class Services2(models.Model):
    class_name = models.CharField(max_length=15)
    name = models.CharField(max_length=255)
    intro = models.CharField(max_length=255)
    image = models.ImageField(upload_to='media/')

    def __str__(self):
        return self.name

# blog
class Blog(models.Model):
    blog_image = models.ImageField(upload_to='media/')
    blog_name = models.CharField(max_length=255)
    blog_title = models.CharField(max_length=255)
    blog_datetime = models.CharField(max_length=255)

    def __str__(self):
        return self.blog_name

# my_skills
class Skill(models.Model):
    skill_accuracy = models.IntegerField()
    Skill_name = models.CharField(max_length=255)

    def __str__(self):
        return self.Skill_name
    