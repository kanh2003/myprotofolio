from django.contrib import admin
from .models import Contact,User,About,Services,Services2,Blog,Skill

# Register your models here.
admin.site.register(Contact)
admin.site.register(User)
admin.site.register(About)
admin.site.register(Services)
admin.site.register(Services2)
admin.site.register(Blog)
admin.site.register(Skill)