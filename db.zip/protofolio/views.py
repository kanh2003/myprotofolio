from django.shortcuts import render
from django.http import HttpResponse
from protofolio.models import Contact,User,About,Services,Services2,Blog,Skill
# Create your views here.
def index(request):
        # Home
    home = User.objects.latest('updated')

    # about
    about = About.objects.latest('updated')

    # services
    service = Services.objects.all()

    # services
    service2 = Services2.objects.all()

    # Blog
    blog = Blog.objects.all()

    # Skill
    skill = Skill.objects.all()


    context = {
        'home' : home,
        'about' : about,
        'service' : service,
        'service2' : service2,
        'blog' : blog,
        'skill' : skill,
    }
    if request.method=='POST':
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        mobile = request.POST['mobile']
        subject = request.POST['subject']
        message = request.POST['message']
        # print(fname,lname,email,mobile,subject,message)
        contact = Contact(fname=fname,lname=lname,email=email,mobile=mobile,subject=subject,message=message)
        contact.save()
    return render(request,'index.html',context)



